#!/bin/sh
rundir="/WORK/DB/seed";
echo "Enter mysql at $rundir"
if [ $# -lt 2 ]; then
/usr/local/mysql/bin/mysql  --socket="$rundir"/mysql.sock -u root -p`cat $rundir/mysql.security.ini`
#/usr/local/mysql/bin/mysql  --socket="$rundir"/mysql.sock -u root
else
/usr/local/mysql/bin/mysql  --socket="$rundir"/mysql.sock $2 $3 $4
fi
