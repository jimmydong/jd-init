#!/bin/sh
ulimit -SHn 51200
/usr/local/varnish/sbin/varnishd -n /var/vcache -f /YOKA/VARNISH/varnish.conf -a 59.151.9.86:80 -s file,/var/vcache/varnish_cache.data,2G -u www -w 128,2048,15 -T 127.0.0.1:3500
#/usr/local/varnish/sbin/varnishd -n /var/vcache_persistence -f /CM/VARNISH/varnish.vcl -a 211.99.203.124:80 -s persistence,/var/vcache/varnish_cache.data,32G -u www -w 128,2048,15 -T 127.0.0.1:3500
/usr/local/varnish/bin/varnishncsa -n /var/vcache -w /YOKA/VARNISH/varnish.log &

