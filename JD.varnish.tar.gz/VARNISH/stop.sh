#!/bin/sh
killall varnishd
killall varnishncsa
