#!/bin/sh
rundir="/WORK2/testdb";
echo "Enter mysql at $rundir"
if [ $# -lt 2 ]; then
/usr/local/mysql/bin/mysql  --socket="$rundir"/mysql.sock -u root -p`cat $rundir/mysql.security.ini`
#/usr/local/mysql/bin/mysql  --socket="$rundir"/mysql.sock -u root
else
/usr/local/mysql/bin/mysql  --socket="$rundir"/mysql.sock $2 $3 $4
fi
