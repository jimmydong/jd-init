#!/bin/sh
rundir=$(cd $(dirname "${BASH_SOURCE[0]}") >/dev/null && pwd)
echo never > /sys/kernel/mm/redhat_transparent_hugepage/defrag
echo never > /sys/kernel/mm/redhat_transparent_hugepage/enabled
echo never > /sys/kernel/mm/transparent_hugepage/enabled
echo never > /sys/kernel/mm/transparent_hugepage/defrag

echo "Start mysql at $rundir"
#/usr/local/percona/bin/mysqld_safe --defaults-file="$rundir"/my_5.5.cnf  --pid-file="$rundir"/mysql.pid --datadir="$rundir"/var --socket="$rundir"/mysql.sock --log-error="$rundir"/err.log --slow-query-log --slow-query-log-file="$rundir"/slow_query.log --log-bin="$rundir"/var/mysql-bin &
/usr/local/percona/bin/mysqld_safe --defaults-file="$rundir"/my5.5.cnf  --pid-file="$rundir"/mysql.pid --datadir="$rundir"/var --socket="$rundir"/mysql.sock --log-error="$rundir"/err.log --slow-query-log --slow-query-log-file="$rundir"/slow_query.log  &

