################################################
# MySQL 5.1 Seed by jimmy 20070311
Install:
download from mysql.com: Linux (non RPM, Intel C/C++ compiled, glibc-2.3) ,
x86 or x86_64
untar to /usr/local/mysql-x.x, ln -s /usr/local/mysql-x.x /usr/local/mysql
edit my.cnf
untar the seed in /YOKA/DB/server0
be sure you have place db_start.sh, db_stop.sh, db_enter.sh in /YOKA/SBIN/
OK! Let's begin with:  db_start.sh server0
Done!

Other:
if you want use admin as 'root', start or stop like this: db_stop.sh server0
-u root

Good Luck!
