default user:

1, mysql  localhost pass=NULL
2, yoka   everywhere pass=yoka.com
3, yoka2312 localhost pass=/home/mysql/mysql.security.ini
4, root   localhost  !!!NO privileges!!!
