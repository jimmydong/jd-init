#!/bin/sh
convmv -f utf8 -t GBK -r --notest $1
chown yoka.yoka $1 -R
