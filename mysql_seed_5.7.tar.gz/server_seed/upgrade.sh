#!/bin/sh
if [ "$1" == "" ]; then
echo -e "!!!"
echo -e "Important:  Must set skip-slave-start and skip-networking"
echo -e "Usage: ./upgrade.sh force [...]\n"
exit
fi

echo -e "upgrade mysql ..."
if [ $# -lt 2 ]; then
/usr/local/mysql/bin/mysql_upgrade --socket=./mysql.sock -u root -p`cat mysql.security.ini`
else
/usr/local/mysql/bin/mysql_upgrade --socket=./mysql.sock $2 $3 $4 $5 $6
fi

