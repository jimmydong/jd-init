/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: socks5p.h,v 1.15.4.1 1999/02/03 22:34:55 steve Exp $
 */

#ifndef SOCKS5P_H
#define SOCKS5P_H

/* everybody can include this...it just cleans up the code...                */

#include "config.h"
#include "hide.h"
#include "includes.h"
#include "hide.h"
#include "defs.h"
#include "socks5api.h"
#include "system.h"
#include "protos.h"

#endif
