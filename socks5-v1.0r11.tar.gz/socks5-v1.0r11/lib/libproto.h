/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: libproto.h,v 1.10.4.1 1999/02/03 22:35:12 steve Exp $
 */

#ifndef LIBPROTO_H
#define LIBPROTO_H

/* Best case scenario, since we shouldn't be using ip options.               */
#define UDP_MAX_PAYLOAD ((2<<16) - 18 - 8) 

lsSocksInfo *lsLibProtoExchg   P((S5IOHandle, const S5NetAddr *, u_char));
int          lsLibSendRequest  P((lsSocksInfo *, const S5NetAddr *, u_char));
int          lsLibReadResponse P((lsSocksInfo *));
int          lsLibExchgUdpCmd  P((lsSocksInfo *, const S5NetAddr *, u_char));

#endif
