/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: buffer.h,v 1.12.4.2 1999/02/03 22:35:01 steve Exp $
 */

#ifndef BUFFER_H
#define BUFFER_H

extern void S5BufCleanContext P((S5IOInfo *));
extern void S5BufSetupContext P((S5IOInfo *));
extern int  S5BufUnreadPacket P((S5IOInfo *, char *, int));
extern int  S5BufReadPacket   P((S5IOHandle, S5IOInfo *, char *, int, int));
extern int  S5BufWritePacket  P((S5IOHandle, S5IOInfo *, char *, int, int));
extern int  S5BufCheckPacket  P((S5IOHandle, S5IOInfo *));
extern int  S5BufCheckData    P((S5IOHandle, S5IOInfo *));

#endif

