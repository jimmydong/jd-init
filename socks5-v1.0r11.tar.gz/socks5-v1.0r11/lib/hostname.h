/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: hostname.h,v 1.7.4.3 1999/02/03 22:35:10 steve Exp $
 */

#ifndef __HOSTNAME_H__
#define __HOSTNAME_H__

extern int  lsGetCachedHostname P((const S5NetAddr *, char *, int));
extern int  lsGetCachedAddress  P((const char *, S5NetAddr *));

#endif
