/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: msg.h,v 1.13.4.1 1999/02/03 22:35:16 steve Exp $
 */

#ifndef MSG_H
#define MSG_H

extern int S5IORecv  P((S5IOHandle, S5IOInfo *, char *, int, int, int, double *));
extern int S5IOSend  P((S5IOHandle, S5IOInfo *, char *, int, int, int, double *));
extern int S5IOCheck P((S5IOHandle));

#define S5_IOFLAGS_NBYTES  0x01
#define S5_IOFLAGS_TIMED   0x02
#define S5_IOFLAGS_RESTART 0x04

#endif
