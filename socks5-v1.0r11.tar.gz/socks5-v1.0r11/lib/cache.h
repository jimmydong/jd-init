/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: cache.h,v 1.11.4.1 1999/02/03 22:35:03 steve Exp $
 */

#ifndef CACHE_H
#define CACHE_H

extern void         lsProxyCacheClean  P((      lsSocksInfo *));
extern void         lsProxyCacheDel    P((      lsSocksInfo *, lsProxyInfo *));
extern lsProxyInfo *lsProxyCacheAdd    P((      lsSocksInfo *, const S5NetAddr *, u_char));
extern lsProxyInfo *lsProxyCacheFind   P((const lsSocksInfo *, const S5NetAddr *, u_char, int));

extern int          lsConnectionDel    P((S5IOHandle));
extern int          lsConnectionCached P((S5IOHandle));
extern lsSocksInfo *lsConnectionAdd    P((S5IOHandle));
extern lsSocksInfo *lsConnectionFind   P((S5IOHandle));

extern lsSocksInfo *lsConList;	  /* list of known connections               */
extern lsSocksInfo *lsLastCon;    /* last successful connect()               */

#define PROTO(cmd) ((cmd) == SOCKS_UDP?SOCK_DGRAM:SOCK_STREAM)

#endif
