/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: null.h,v 1.8.4.1 1999/02/03 22:35:17 steve Exp $
 */

#ifndef NULL_H
#define NULL_H

extern int lsNullCliAuth P((S5IOHandle, S5AuthInfo *, char *));
extern int lsNullSrvAuth P((S5IOHandle, S5AuthInfo *, char *));

#endif
