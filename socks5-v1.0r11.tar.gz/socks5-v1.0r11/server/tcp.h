/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: tcp.h,v 1.8.4.1 1999/02/03 22:35:49 steve Exp $
 */

/* This file (tcp.h) describes the external interface to all the functions   */
/* provided in tcp.c.  In particular, it only describes one function,        */
/* HandleTcpConnection.                                                      */
#ifndef TCP_H
#define TCP_H

extern int TcpSetup P((S5IOInfo *, S5LinkInfo *, S5CommandInfo *));

#endif
