/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: socket.h,v 1.5.4.1 1999/02/03 22:35:47 steve Exp $
 */

/* This file contains all the prototypes for the socket setup/connections.   */
#ifndef SOCKET_H
#define SOCKET_H

extern void GetConnection P((void)); /* A function to get a Connection.      */

#endif

