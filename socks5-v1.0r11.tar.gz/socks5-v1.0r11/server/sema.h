/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: sema.h,v 1.11.4.2 1999/02/03 22:35:43 steve Exp $
 */

#ifndef SEMA_H
#define SEMA_H

#if defined(USE_SYSTEM_SEMAPHORE) || defined(USE_SEMAPHORES)

extern void *semcreate  P((int));
extern void  semdestroy P((void *));
extern int   semreset   P((void *, int));
extern int   semacquire P((void *));
extern int   semrelease P((void *));

#else

#define semcreate(i)    NULL
#define semacquire(s)   0
#define semdestroy(s)
#define semrelease(s)
#define semreset(s, v)  

#endif
#endif
