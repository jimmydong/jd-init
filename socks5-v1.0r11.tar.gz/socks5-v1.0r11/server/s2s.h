/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: s2s.h,v 1.4.4.1 1999/02/03 22:35:42 steve Exp $
 */

#ifndef S2S_H
#define S2S_H

extern int S5SExchangeProtocol P((S5IOInfo *, S5IOInfo *, S5LinkInfo *, char *, S5NetAddr *, S5NetAddr *));
extern int S5SExchgUdpCmd P((S5IOHandle, S5IOInfo *, S5LinkInfo *, u_char, u_char, u_char *));

#endif
