/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: flow.h,v 1.6.4.1 1999/02/03 22:35:34 steve Exp $
 */

#ifndef FLOW_H
#define FLOW_H

extern int S5TcpFlowRecv P((S5IOInfo *, S5IOInfo *, S5Packet *, int *));
extern int S5TcpFlowSend P((S5IOInfo *, S5IOInfo *, S5Packet *, int *));

#endif

