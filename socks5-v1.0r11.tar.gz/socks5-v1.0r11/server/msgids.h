/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: msgids.h,v 1.3.4.1 1999/02/03 22:35:37 steve Exp $
 */

#ifndef __MSGIDS_H
#define __MSGIDS_H

#define MSGID_SERVER_START              1
#define MSGID_SERVER_RESTART            2
#define MSGID_SERVER_STOP               3

#define MSGID_SERVER_SOCKS_BIND         4
#define MSGID_SERVER_SOCKS_ACCEPT       5

#define MSGID_SERVER_CONF_BADLINE       6

#define MSGID_SERVER_AUTH_BAD           7
#define MSGID_SERVER_AUTH_NONE          8
#define MSGID_SERVER_AUTH_FAILED        9

#define MSGID_SERVER_WRONG_ROUTE        10
#define MSGID_SERVER_BANNED_HOST        11
#define MSGID_SERVER_BAD_VERSION        12
#define MSGID_SERVER_RECV_VERSION       13
#define MSGID_SERVER_BAD_COMMAND        14

#define MSGID_SERVER_TCP_START          15
#define MSGID_SERVER_TCP_ESTAB          16
#define MSGID_SERVER_TCP_END            17
#define MSGID_SERVER_TCP_AUTH           18
#define MSGID_SERVER_TCP_ACCEPT_AUTH    19

#define MSGID_SERVER_UDP_START          20
#define MSGID_SERVER_UDP_ESTAB          21
#define MSGID_SERVER_UDP_END            22
#define MSGID_SERVER_UDP_AUTH           23

#define MSGID_SERVER_PT_START           24
#define MSGID_SERVER_PT_ESTAB           25
#define MSGID_SERVER_PT_END             26
#define MSGID_SERVER_PT_AUTH            27

#endif
