/* Copyright (c) 1996-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("COPYRIGHT") included with this distribution.                   */
#ifndef SHARE_H
#define SHARE_H

#define DONT_NEED_SIGBLOCK
#define DONT_NEED_SIGPAUSE
#define DONT_NEED_SIGUNBLOCK
#define DONT_NEED_SIGPENDING
#include "sigfix.h"

extern struct hostent *LIBPREFIX(gethostbyname) P((const char *));
extern int LIBPREFIX(close) P((S5IOHandle));

extern int DataRelay P((S5IOHandle, S5IOInfo *, int));

#endif
