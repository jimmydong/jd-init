#!/usr/bin/python2.7
from subprocess import Popen,PIPE
import sys
import os
whitelist = ['127.0.0.1','10.162.62.72','10.162.77.43','10.162.83.24','10.162.93.64','10.161.210.80','47.90.17.1','121.69.30.230','219.143.178.166']
line = sys.stdin.readline()
while line:
	info = line.strip().replace('"','').split()
	if int(info[0]) > 300 and info[1] not in whitelist:
		cmd = '/sbin/iptables -I INPUT -s %s/32 -p tcp --dport 80 -j DROP -w' % info[1]
		print '[' + info[0] + '] ' + cmd
		Popen(cmd, shell=True, bufsize=1024, stdout=PIPE).stdout
		cmd = '/sbin/iptables -D INPUT -s %s/32 -p tcp -p tcp --dport 80 -j DROP | at now +24hours' % info[1]
		Popen(cmd, shell=True, bufsize=1024, stdout=PIPE).stdout
	line = sys.stdin.readline()

