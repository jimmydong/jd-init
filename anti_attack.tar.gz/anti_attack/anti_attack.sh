#!/bin/sh
echo
echo 'Anti Attack need to run per 15mins'
echo 
#*/15 * * * * (cd /WORK/LOG/apache_logs;date >> anti_attack.log;./anti_attack.sh >> anti_attack.log 2>&1)

/WORK/SBIN/apache_csv.sh api
cat apache_log.csv | grep 'hosts'  | awk -F ',' '{print $4 , $12}' | ./apache_log.py
echo '' > access_log.api.`date +%Y%m%d`

