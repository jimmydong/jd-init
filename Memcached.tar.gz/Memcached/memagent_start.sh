#!/bin/sh
####################################################################
# memcached agent v0.4 Build-Date: Aug  5 2009 11:47:40
# Usage:
#  -h this message
#  -u uid
#  -g gid
#  -p port, default is 11211. (0 to disable tcp support)
#  -s ip:port, set memcached server ip and port
#  -b ip:port, set backup memcached server ip and port
#  -l ip, local bind ip address, default is 0.0.0.0
#  -n number, set max connections, default is 4096
#  -D don't go to background
#  -k use ketama key allocation algorithm
#  -f file, unix socket path to listen on. default is off
#  -i number, set max keep alive connections for one memcached server, default is 20
#  -v verbose

magent_path=/YOKA/Memcached
$magent_path/magent -u root -n 10000 -l 10.0.0.82.1 -p 11213 -s 10.0.0.83:11213 -s 10.0.0.84:11213 -s 10.0.0.85:11213 -b 10.0.0.211:11311
