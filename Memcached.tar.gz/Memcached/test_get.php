#!/usr/local/php/bin/php
<?
$keylist=array('111','222','333','444','555'); //do not change

$memcache_obj = new Memcache;
$memcache_obj->connect('127.0.0.1', 11211);
foreach($keylist as $key){
	echo $key.":".$memcache_obj->get($key)."<br>\n";
}

