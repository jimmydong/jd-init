#!/usr/local/php/bin/php
<?
$keylist=array('111','222','333','444','555'); //do not change

//you can change this
$datalist=array('adfe3',223434,'asdfjaslkfdjsalefef','223434','aaaa');
$datalist2=array('ASDFASDFA','DDDDD','ASDF3@##$','SDFASDF"DJH..','ASDF33333');

$memcache_obj = new Memcache;
$memcache_obj->connect('127.0.0.1', 11211);
foreach($keylist as $k=>$key){
	$memcache_obj->set($key,$datalist2[$k]);
}

