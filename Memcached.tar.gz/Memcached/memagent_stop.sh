#!/bin/sh
killall magent
