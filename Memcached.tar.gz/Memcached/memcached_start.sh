#!/bin/sh
#
# memcached config for standard fornt web server
# 
# !!! change the ip to real !!!
ip='10.0.0.87'

# start local memcached
/usr/local/bin/memcached -d -u root -m 2048 -l 127.0.0.1 -p 11211 -c 100000 -P /YOKA/Memcached/memcached_local.pid
# start group memcached
/usr/local/bin/memcached -d -u root -m 1024 -l $ip -p 11213 -c 100000 -P /YOKA/Memcached/memcached_group.pid

